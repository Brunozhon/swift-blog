import SwiftUI

struct Run: Equatable, Hashable, Identifiable {
    var id: UUID = UUID()
    var name: String
    var miles: Double
    var iconColor: Color
}
