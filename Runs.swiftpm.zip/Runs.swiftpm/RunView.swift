import SwiftUI

struct RunView: View {
    @Environment(\.editMode) var editMode
    
    @Binding var run: Run
    
    var body: some View {
        VStack {
            HStack {
                Spacer()
                EditButton()
            }
            Image(systemName: "figure.walk")
                .imageScale(.large)
                .foregroundColor(run.iconColor)
            if editMode?.wrappedValue == .inactive {
                Text("\(run.name)")
                    .font(.title)
                Text("Miles ran: \(run.miles) miles")
            } else {
                TextField("Run Name", text: $run.name)
                    .font(.title)
                HStack {
                    Stepper(value: $run.miles, step: 0.1) {
                        Text("Miles ran:")
                    }
                    Text("\(run.miles) miles")
                        .redacted(reason: .privacy)
                }
                ColorPicker("Icon Color", selection: $run.iconColor)
            }
        }
    }
}

struct RunView_Previews: PreviewProvider {
    static var previews: some View {
        RunView(run: .constant(Run(
            name: "My Run", miles: 0.5, iconColor: .green
        )))
    }
}
