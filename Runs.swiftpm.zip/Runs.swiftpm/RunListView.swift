import SwiftUI

struct RunListView: View {
    @State private var runs = [
        Run(name: "My First Run", miles: 0.5, iconColor: .yellow),
        Run(name: "The One-Mile Mark Run", miles: 1.1, iconColor: .green)
    ]
    
    var body: some View {
        List($runs) { run in
            NavigationLink(run.name.wrappedValue, destination: RunView(run: run))
        }
    }
}

struct RunListView_Previews: PreviewProvider {
    static var previews: some View {
        RunListView()
    }
}
