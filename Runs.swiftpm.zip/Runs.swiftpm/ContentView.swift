import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            RunListView()
                .navigationTitle("Runs")
        }
    }
}
